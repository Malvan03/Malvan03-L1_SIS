package pe.linea1.servlet;

import pe.linea1.dao.ConductorDAO;
import pe.linea1.model.Conductor;
import pe.linea1.model.Usuario;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.*;

public class GestionConductoresServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Imprimir todos los atributos de la sesión para depuración
            HttpSession session = request.getSession(false);
            System.out.println("==== DEPURACIÓN DE SESIÓN ====");
            System.out.println("ID de sesión: " + (session != null ? session.getId() : "null"));
            
            if (session != null) {
                Enumeration<String> atributos = session.getAttributeNames();
                while (atributos.hasMoreElements()) {
                    String nombre = atributos.nextElement();
                    System.out.println("Atributo: " + nombre + " = " + session.getAttribute(nombre));
                }
            } else {
                System.out.println("Sesión es NULL");
                session = request.getSession(true);
                System.out.println("Nueva sesión creada: " + session.getId());
            }
            
            // Crear sesión si no existe
            session = request.getSession();
            
            // Validar usuario en sesión
            Usuario usuario = (Usuario) session.getAttribute("usuario");
            if (usuario == null) {
                System.out.println("ERROR: No hay usuario en la sesión");
                
                // En lugar de redireccionar, vamos a cargar una lista vacía
                // y mostrar un mensaje informativo
                request.setAttribute("error", "Sesión expirada o no iniciada. Por favor, vuelva a iniciar sesión.");
                request.setAttribute("listaConductores", new ArrayList<>());
                request.getRequestDispatcher("gestion_conductores.jsp").forward(request, response);
                return;
            }
            
            // Intentar buscar los conductores
            ConductorDAO conductorDAO = new ConductorDAO();
            List<Conductor> lista = null;
            
            String dni = request.getParameter("dni");
            String modalidad = request.getParameter("modalidad");
            String estado = request.getParameter("estado");
            String fechaIngresoStr = request.getParameter("fechaIngreso");
            java.sql.Date fechaIngreso = null;
            
            System.out.println("Parámetros recibidos:");
            System.out.println("DNI: " + dni);
            System.out.println("Modalidad: " + modalidad);
            System.out.println("Estado: " + estado);
            System.out.println("Fecha: " + fechaIngresoStr);
            
            // Convertir fecha si está presente
            if (fechaIngresoStr != null && !fechaIngresoStr.trim().isEmpty()) {
                try {
                    fechaIngreso = java.sql.Date.valueOf(fechaIngresoStr);
                } catch (Exception e) {
                    System.out.println("Error al parsear fecha: " + e.getMessage());
                }
            }
            
            // Realizar la búsqueda adecuada
            boolean hayFiltros = (dni != null && !dni.trim().isEmpty()) || 
                                (modalidad != null && !modalidad.trim().isEmpty()) ||
                                (estado != null && !estado.trim().isEmpty()) ||
                                fechaIngreso != null;
            
            try {
                if (hayFiltros) {
                    lista = conductorDAO.buscarConductores(dni, modalidad, estado, fechaIngreso);
                    System.out.println("Búsqueda con filtros completada");
                } else {
                    lista = conductorDAO.listarTodos();
                    System.out.println("Listado de todos los conductores");
                }
                
                if (lista == null) lista = new ArrayList<>();
                System.out.println("Conductores encontrados: " + lista.size());
                
            } catch (Exception e) {
                System.out.println("Error en la búsqueda: " + e.getMessage());
                e.printStackTrace();
                lista = new ArrayList<>();
                request.setAttribute("error", "Error en la búsqueda: " + e.getMessage());
            }
            
            // Establecer atributos y mostrar la página
            request.setAttribute("listaConductores", lista);
            request.setAttribute("dni", dni);
            request.setAttribute("modalidad", modalidad);
            request.setAttribute("estado", estado);
            request.setAttribute("fechaIngreso", fechaIngresoStr);
            
            request.getRequestDispatcher("gestion_conductores.jsp").forward(request, response);
            
        } catch (Exception ex) {
            System.out.println("Error general: " + ex.getMessage());
            ex.printStackTrace();
            request.setAttribute("error", "Error en el servidor: " + ex.getMessage());
            request.setAttribute("listaConductores", new ArrayList<>());
            request.getRequestDispatcher("gestion_conductores.jsp").forward(request, response);
        }
    }
}