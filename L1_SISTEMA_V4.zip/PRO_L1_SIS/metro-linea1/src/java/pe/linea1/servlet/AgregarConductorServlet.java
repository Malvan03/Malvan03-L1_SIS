package pe.linea1.servlet;

import pe.linea1.dao.ConductorDAO;
import pe.linea1.model.Conductor;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

//@WebServlet("/AgregarConductorServlet")
public class AgregarConductorServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        try {
            Conductor conductor = new Conductor();
            conductor.setIdUsuario(Integer.parseInt(request.getParameter("idUsuario")));
            conductor.setModalidad(request.getParameter("modalidad"));
            conductor.setBase(request.getParameter("base"));

            String fechaIngresoStr = request.getParameter("fechaIngreso");
            java.util.Date fechaIngreso = null;
            if (fechaIngresoStr != null && !fechaIngresoStr.isEmpty()) {
                try {
                    fechaIngreso = new java.text.SimpleDateFormat("yyyy-MM-dd").parse(fechaIngresoStr);
                } catch (Exception e) {
                    fechaIngreso = null;
                }
            }
            conductor.setFechaIngreso(fechaIngreso);

            conductor.setHabilitado(Boolean.parseBoolean(request.getParameter("habilitado")));
            conductor.setEstadoPersonal(request.getParameter("estadoPersonal"));
            conductor.setObservaciones(request.getParameter("observaciones"));

            new ConductorDAO().insertar(conductor);

            response.sendRedirect("GestionConductoresServlet");
        } catch (Exception ex) {
            ex.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}