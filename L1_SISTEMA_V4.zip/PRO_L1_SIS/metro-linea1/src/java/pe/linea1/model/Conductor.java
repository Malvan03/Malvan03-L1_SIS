package pe.linea1.model;

import java.util.Date;

public class Conductor {
    private int idConductor;
    private int idUsuario;
    private String dni;
    private String nombres;
    private String apellidos;
    private String correo;
    private String telefono;
    private String modalidad;
    private String turnoActual;  // Añadido según requerimiento
    private String base;
    private Date fechaIngreso;
    private boolean habilitado;
    private String estadoPersonal;
    private String observaciones;
    private Usuario usuario; // Referencia al objeto Usuario

    // Getters y Setters originales
    public int getIdConductor() { return idConductor; }
    public void setIdConductor(int idConductor) { this.idConductor = idConductor; }

    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }

    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }

    public String getNombres() { return nombres; }
    public void setNombres(String nombres) { this.nombres = nombres; }

    public String getApellidos() { return apellidos; }
    public void setApellidos(String apellidos) { this.apellidos = apellidos; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getModalidad() { return modalidad; }
    public void setModalidad(String modalidad) { this.modalidad = modalidad; }

    public String getBase() { return base; }
    public void setBase(String base) { this.base = base; }

    public Date getFechaIngreso() { return fechaIngreso; }
    public void setFechaIngreso(Date fechaIngreso) { this.fechaIngreso = fechaIngreso; }

    public boolean isHabilitado() { return habilitado; }
    public void setHabilitado(boolean habilitado) { this.habilitado = habilitado; }

    public String getEstadoPersonal() { return estadoPersonal; }
    public void setEstadoPersonal(String estadoPersonal) { this.estadoPersonal = estadoPersonal; }

    public String getObservaciones() { return observaciones; }
    public void setObservaciones(String observaciones) { this.observaciones = observaciones; }
    
    // Nuevos getters/setters para campos adicionales
    public String getTurnoActual() { return turnoActual; }
    public void setTurnoActual(String turnoActual) { this.turnoActual = turnoActual; }
    
    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { 
        this.usuario = usuario;
        // Si tenemos un usuario, sincronizamos los campos relevantes
        if (usuario != null) {
            this.idUsuario = usuario.getIdUsuario();
            this.dni = usuario.getDni();
            this.nombres = usuario.getNombres();
            this.apellidos = usuario.getApellidoPaterno() + " " + usuario.getApellidoMaterno();
            this.correo = usuario.getCorreo();
            this.telefono = usuario.getTelefono();
        }
    }
}