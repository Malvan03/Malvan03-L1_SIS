package pe.linea1.dao;

import pe.linea1.model.Usuario;
import pe.linea1.util.DBConnection;
import java.sql.*;
import org.mindrot.jbcrypt.BCrypt;

public class UsuarioDAO {

    // Validar usuario por dni y password encriptado
    public Usuario validarUsuario(String dni, String password) {
        Usuario user = null;
        String sql = "SELECT * FROM USUARIO WHERE dni = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, dni);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String hashAlmacenado = rs.getString("contrasena_hash");
                    if (BCrypt.checkpw(password, hashAlmacenado)) {
                        user = new Usuario();
                        user.setId(rs.getInt("id_usuario"));
                        user.setDni(rs.getString("dni"));
                        user.setNombres(rs.getString("nombres"));
                        user.setApellidos(rs.getString("apellidos"));
                        user.setCorreo(rs.getString("correo"));
                        user.setTelefono(rs.getString("telefono"));
                        user.setContactoEmergencia(rs.getString("contacto_emergencia"));
                        user.setFechaNacimiento(rs.getDate("fecha_nacimiento"));
                        user.setContrasenaHash(hashAlmacenado);
                        user.setRol(rs.getString("rol"));
                        user.setFotoPerfil(rs.getString("foto_perfil"));
                        user.setEstado(rs.getString("estado"));
                        user.setFechaRegistro(rs.getTimestamp("fecha_registro"));
                        user.setFechaUltimoLogin(rs.getTimestamp("fecha_ultimo_login"));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }

    // Insertar nuevo usuario, retorna el id generado
    public int insertar(Usuario u) throws Exception {
        int id = 0;
        String sql = "INSERT INTO USUARIO (dni, nombres, apellidos, correo, telefono, contacto_emergencia, fecha_nacimiento, contrasena_hash, rol, estado) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, u.getDni());
            ps.setString(2, u.getNombres());
            ps.setString(3, u.getApellidos());
            ps.setString(4, u.getCorreo());
            ps.setString(5, u.getTelefono());
            ps.setString(6, u.getContactoEmergencia());
            if (u.getFechaNacimiento() != null) {
                ps.setDate(7, new java.sql.Date(u.getFechaNacimiento().getTime()));
            } else {
                ps.setNull(7, java.sql.Types.DATE);
            }
            ps.setString(8, u.getContrasenaHash());
            ps.setString(9, u.getRol());
            ps.setString(10, u.getEstado());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) id = rs.getInt(1);
            }
        }
        return id;
    }

    // Actualizar datos usuario (sin password ni rol)
    public void actualizar(Usuario u) throws Exception {
        String sql = "UPDATE USUARIO SET nombres=?, apellidos=?, correo=?, telefono=?, contacto_emergencia=?, fecha_nacimiento=? WHERE id_usuario=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, u.getNombres());
            ps.setString(2, u.getApellidos());
            ps.setString(3, u.getCorreo());
            ps.setString(4, u.getTelefono());
            ps.setString(5, u.getContactoEmergencia());
            if (u.getFechaNacimiento() != null) {
                ps.setDate(6, new java.sql.Date(u.getFechaNacimiento().getTime()));
            } else {
                ps.setNull(6, java.sql.Types.DATE);
            }
            ps.setInt(7, u.getId());
            ps.executeUpdate();
        }
    }
}