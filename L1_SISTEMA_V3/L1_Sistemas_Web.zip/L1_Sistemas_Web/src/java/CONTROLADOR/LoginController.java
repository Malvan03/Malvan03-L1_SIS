package CONTROLADOR;

import DAO.Conexion;
import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class LoginController extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String usuario = request.getParameter("usuario");      // En tu sistema es el DNI
        String contrasena = request.getParameter("contrasena");

        // Busca usuario y contraseña (el usuario es el DNI)
        String sql = "SELECT id_conductor, rol FROM Usuarios WHERE usuario = ? AND contrasena_hash = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, usuario);
            ps.setString(2, contrasena); // Si tienes hash, aplica el hash aquí

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String rol = rs.getString("rol");
                int idConductor = rs.getInt("id_conductor"); // Puede ser 0 si ADMIN

                HttpSession session = request.getSession();
                session.setAttribute("usuario", usuario);   // Guarda el DNI
                session.setAttribute("rol", rol);
                session.setAttribute("dni", usuario);       // Para los datos personales

                // Si tienes nombre cargado, podrías consultarlo aquí y guardarlo en sesión:
                // session.setAttribute("nombre_usuario", ...);

                if ("CONDUCTOR".equals(rol)) {
                    session.setAttribute("id_conductor", idConductor);
                    response.sendRedirect("home_conductor.jsp");
                } else if ("ADMIN".equals(rol)) {
                    response.sendRedirect("home_admin.jsp");
                } else {
                    // Rol no válido
                    session.invalidate();
                    request.setAttribute("error", "Rol de usuario no válido.");
                    request.getRequestDispatcher("login.jsp").forward(request, response);
                }

            } else {
                // Usuario/contraseña incorrectos
                request.setAttribute("error", "Credenciales incorrectas");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }

        } catch (Exception e) {
            request.setAttribute("error", "Error en la base de datos: " + e.getMessage());
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
