package CONTROLADOR;

import DAO.DatosPersonalesDAO;
import MODELO.DatosPersonales;
import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;

public class EditarPerfilController extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        String accion = request.getParameter("accion");
        String dni = request.getParameter("dni");
        HttpSession session = request.getSession();

        DatosPersonalesDAO dao = new DatosPersonalesDAO();

        if ("datos".equals(accion)) {
            DatosPersonales dp = new DatosPersonales();
            dp.setDni(dni);
            dp.setNombres(nvl(request.getParameter("nombres")));
            dp.setPrimerApellido(nvl(request.getParameter("primer_apellido")));
            dp.setSegundoApellido(nvl(request.getParameter("segundo_apellido")));
            dp.setTelefono(nvl(request.getParameter("telefono")));
            dp.setCorreo(nvl(request.getParameter("correo")));
            dp.setContactoEmergencia(nvl(request.getParameter("contacto_emergencia")));
            dp.setTelefonoEmergencia(nvl(request.getParameter("telefono_emergencia")));
            dp.setFechaNacimiento(nvl(request.getParameter("fecha_nacimiento")));
            // Por ahora solo la ruta del archivo (mejorar para file upload real)
            String foto = nvl(request.getParameter("foto_perfil"));
            dp.setFotoPerfil(foto);

            boolean ok;
            if (dao.obtenerPorDni(dni) == null) {
                ok = dao.insertar(dp);
            } else {
                ok = dao.actualizar(dp);
            }

            // Actualiza nombre en sesión para mostrarlo en el home
            session.setAttribute("nombre_usuario", dp.getNombres());

            // Redirección con parámetro de éxito
            String rol = (String) session.getAttribute("rol");
            if ("ADMIN".equals(rol)) {
                if (ok) {
                    response.sendRedirect("home_admin.jsp?exito=1");
                } else {
                    response.sendRedirect("editar_perfil.jsp?error=1");
                }
            } else {
                if (ok) {
                    response.sendRedirect("home_conductor.jsp?exito=1");
                } else {
                    response.sendRedirect("editar_perfil.jsp?error=1");
                }
            }
            return;

        } else if ("contrasena".equals(accion)) {
            // lógica de cambio de contraseña aquí si deseas
            session.invalidate();
            response.sendRedirect("login.jsp?contrasena=ok");
            return;
        }

        response.sendRedirect("editar_perfil.jsp?error=1");
    }

    // Método auxiliar para limpiar "null"
    private String nvl(String valor) {
        return (valor == null || valor.trim().equalsIgnoreCase("null")) ? "" : valor.trim();
    }
}
