package CONTROLADOR;

import DAO.SolicitudCambioDAO;
import MODELO.SolicitudCambio;
import java.io.IOException;
import java.util.List;
import javax.servlet.*;
import javax.servlet.http.*;

public class SolicitudesAdminController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String rol = (String) request.getSession().getAttribute("rol");
        if (rol == null || !"ADMIN".equals(rol)) {
            response.sendRedirect("login.jsp");
            return;
        }

        SolicitudCambioDAO dao = new SolicitudCambioDAO();
        List<SolicitudCambio> solicitudesPendientes = dao.listarSolicitudesPendientes();

        request.setAttribute("solicitudes", solicitudesPendientes);
        RequestDispatcher dispatcher = request.getRequestDispatcher("ver_solicitudes.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String rol = (String) request.getSession().getAttribute("rol");
        if (rol == null || !"ADMIN".equals(rol)) {
            response.sendRedirect("login.jsp");
            return;
        }

        int idSolicitud = Integer.parseInt(request.getParameter("id_solicitud"));
        String accion = request.getParameter("accion"); // "SI" o "NO"
        String observacion = request.getParameter("observacion_admin");

        SolicitudCambioDAO dao = new SolicitudCambioDAO();
        dao.actualizarEstadoSolicitud(idSolicitud, accion, observacion);

        response.sendRedirect("ver_solicitudes.jsp");
    }
}
