package CONTROLADOR;

import DAO.ConductorDAO;
import MODELO.Conductor;
import java.io.IOException;
import java.util.List;
import javax.servlet.*;
import javax.servlet.http.*;

public class GestionConductoresController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        // NOTA: Los nombres aquí deben coincidir con los del form en el JSP
        String filtroDni = request.getParameter("dni");
        String filtroModalidad = request.getParameter("modalidad");
        String filtroEstado = request.getParameter("estado");

        ConductorDAO dao = new ConductorDAO();
        List<Conductor> lista = dao.filtrarConductores(
            filtroDni != null ? filtroDni : "",
            filtroModalidad != null ? filtroModalidad : "",
            filtroEstado != null ? filtroEstado : ""
        );
        request.setAttribute("lista", lista);

        // Llama al JSP
        request.getRequestDispatcher("gestion_conductores.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        // Implementa lógica de agregar/editar si deseas
        response.sendRedirect("GestionConductoresController");
    }
}
