package CONTROLADOR;

import DAO.SolicitudCambioDAO;
import MODELO.SolicitudCambio;
import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;

public class SolicitarCambioController extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String accion = request.getParameter("accion");
        if ("insertar".equals(accion)) {
            SolicitudCambio s = new SolicitudCambio();
            // Completa los setters con lo que recibes del formulario
            s.setNombreSolicitante(request.getParameter("nombre_solicitante"));
            s.setNombreReceptor(request.getParameter("nombre_receptor"));
            s.setTurnoSolicitante(request.getParameter("turno_solicitante"));
            s.setTurnoReceptor(request.getParameter("turno_receptor"));
            // y los campos necesarios...

            SolicitudCambioDAO dao = new SolicitudCambioDAO();
            dao.insertar(s);

            response.sendRedirect("estado_solicitudes.jsp");
        } else {
            response.sendRedirect("solicitar_cambio.jsp?error=1");
        }
    }
}
