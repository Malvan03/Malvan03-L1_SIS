package DAO;

import MODELO.SolicitudCambio;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SolicitudCambioDAO {

    // Listar todas las solicitudes pendientes (filtro: solo SI del receptor y PENDIENTE del admin)
    public List<SolicitudCambio> listarSolicitudesPendientes() {
        List<SolicitudCambio> lista = new ArrayList<>();
        String sql = "SELECT sc.id_solicitud, sc.fecha_solicitud, " +
                     "solicitante.nombre_completo AS nombre_solicitante, " +
                     "receptor.nombre_completo AS nombre_receptor, " +
                     "asig1.id_turno AS turno_solicitante, asig2.id_turno AS turno_receptor, " +
                     "sc.observacion_admin " +
                     "FROM SolicitudesCambio sc " +
                     "JOIN Conductores solicitante ON sc.id_conductor_solicitante = solicitante.id_conductor " +
                     "JOIN Conductores receptor ON sc.id_conductor_receptor = receptor.id_conductor " +
                     "JOIN Asignaciones asig1 ON sc.id_asignacion_original = asig1.id_asignacion " +
                     "JOIN Asignaciones asig2 ON sc.id_asignacion_solicitada = asig2.id_asignacion " +
                     "WHERE sc.estado_receptor = 'SI' AND sc.estado_admin = 'PENDIENTE'";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                SolicitudCambio s = new SolicitudCambio();
                s.setId(rs.getInt("id_solicitud"));
                s.setFechaSolicitud(rs.getString("fecha_solicitud"));
                s.setNombreSolicitante(rs.getString("nombre_solicitante"));
                s.setNombreReceptor(rs.getString("nombre_receptor"));
                s.setTurnoSolicitante(rs.getString("turno_solicitante"));
                s.setTurnoReceptor(rs.getString("turno_receptor"));
                s.setObservacionAdmin(rs.getString("observacion_admin"));
                lista.add(s);
            }
        } catch (Exception e) {
            System.out.println("❌ Error listando solicitudes: " + e.getMessage());
        }
        return lista;
    }

    // Cambiar estado de solicitud de cambio (APROBAR o RECHAZAR)
    public boolean actualizarEstadoSolicitud(int idSolicitud, String estado, String observacion) {
        String sql = "UPDATE SolicitudesCambio SET estado_admin = ?, observacion_admin = ? WHERE id_solicitud = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, estado); // "SI" o "NO"
            ps.setString(2, observacion);
            ps.setInt(3, idSolicitud);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.out.println("❌ Error actualizando estado: " + e.getMessage());
            return false;
        }
    }

    // Insertar una nueva solicitud de cambio
    public boolean insertar(SolicitudCambio s) {
        String sql = "INSERT INTO SolicitudesCambio " +
                     "(fecha_solicitud, fecha_turno, id_conductor_solicitante, id_conductor_receptor, id_asignacion_original, id_asignacion_solicitada, estado_receptor, estado_admin, observacion_admin, comentarios_conductor) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, s.getFechaSolicitud());
            ps.setString(2, s.getFechaSolicitud()); // O usa s.getFechaTurno() si lo tienes en tu modelo
            ps.setInt(3, s.getIdConductorSolicitante());
            ps.setInt(4, s.getIdConductorReceptor());
            ps.setInt(5, s.getIdAsignacionOriginal());
            ps.setInt(6, s.getIdAsignacionSolicitada());
            ps.setString(7, "PENDIENTE");
            ps.setString(8, "PENDIENTE");
            ps.setString(9, s.getObservacionAdmin() != null ? s.getObservacionAdmin() : "");
            ps.setString(10, s.getComentariosConductor() != null ? s.getComentariosConductor() : "");
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.out.println("❌ Error insertando solicitud: " + e.getMessage());
            return false;
        }
    }

    // Listar solicitudes de cambio por conductor (para el historial)
    public List<SolicitudCambio> getPorConductor(Integer idConductor) {
        List<SolicitudCambio> lista = new ArrayList<>();
        String sql = "SELECT sc.id_solicitud, sc.fecha_solicitud, " +
                     "solicitante.nombre_completo AS nombre_solicitante, " +
                     "receptor.nombre_completo AS nombre_receptor, " +
                     "asig1.id_turno AS turno_solicitante, asig2.id_turno AS turno_receptor, " +
                     "sc.observacion_admin " +
                     "FROM SolicitudesCambio sc " +
                     "JOIN Conductores solicitante ON sc.id_conductor_solicitante = solicitante.id_conductor " +
                     "JOIN Conductores receptor ON sc.id_conductor_receptor = receptor.id_conductor " +
                     "JOIN Asignaciones asig1 ON sc.id_asignacion_original = asig1.id_asignacion " +
                     "JOIN Asignaciones asig2 ON sc.id_asignacion_solicitada = asig2.id_asignacion " +
                     "WHERE sc.id_conductor_solicitante = ? OR sc.id_conductor_receptor = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idConductor);
            ps.setInt(2, idConductor);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                SolicitudCambio sc = new SolicitudCambio();
                sc.setId(rs.getInt("id_solicitud"));
                sc.setFechaSolicitud(rs.getString("fecha_solicitud"));
                sc.setNombreSolicitante(rs.getString("nombre_solicitante"));
                sc.setNombreReceptor(rs.getString("nombre_receptor"));
                sc.setTurnoSolicitante(rs.getString("turno_solicitante"));
                sc.setTurnoReceptor(rs.getString("turno_receptor"));
                sc.setObservacionAdmin(rs.getString("observacion_admin"));
                lista.add(sc);
            }
        } catch (Exception e) {
            System.out.println("❌ Error en getPorConductor: " + e.getMessage());
        }
        return lista;
    }
}
