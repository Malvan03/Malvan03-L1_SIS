package DAO;

import MODELO.DatosPersonales;
import java.sql.*;

public class DatosPersonalesDAO {

    public DatosPersonales obtenerPorDni(String dni) {
        DatosPersonales dp = null;
        String sql = "SELECT * FROM DatosPersonales WHERE dni = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, dni);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                dp = new DatosPersonales();
                dp.setDni(rs.getString("dni"));
                dp.setNombres(rs.getString("nombres"));
                dp.setPrimerApellido(rs.getString("primer_apellido"));
                dp.setSegundoApellido(rs.getString("segundo_apellido"));
                dp.setTelefono(rs.getString("telefono"));
                dp.setCorreo(rs.getString("correo"));
                dp.setContactoEmergencia(rs.getString("contacto_emergencia"));
                dp.setTelefonoEmergencia(rs.getString("telefono_emergencia"));
                dp.setFechaNacimiento(rs.getString("fecha_nacimiento"));
                dp.setFotoPerfil(rs.getString("foto_perfil"));
            }
        } catch (Exception e) {
            System.out.println("❌ Error al obtener datos personales: " + e.getMessage());
        }
        return dp;
    }

    public boolean actualizar(DatosPersonales dp) {
        String sql = "UPDATE DatosPersonales SET nombres=?, primer_apellido=?, segundo_apellido=?, telefono=?, correo=?, contacto_emergencia=?, telefono_emergencia=?, fecha_nacimiento=?, foto_perfil=? WHERE dni=?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, dp.getNombres());
            ps.setString(2, dp.getPrimerApellido());
            ps.setString(3, dp.getSegundoApellido());
            ps.setString(4, dp.getTelefono());
            ps.setString(5, dp.getCorreo());
            ps.setString(6, dp.getContactoEmergencia());
            ps.setString(7, dp.getTelefonoEmergencia());
            ps.setString(8, dp.getFechaNacimiento());
            ps.setString(9, dp.getFotoPerfil());
            ps.setString(10, dp.getDni());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.out.println("❌ Error al actualizar datos personales: " + e.getMessage());
            return false;
        }
    }

    public boolean insertar(DatosPersonales dp) {
        String sql = "INSERT INTO DatosPersonales (dni, nombres, primer_apellido, segundo_apellido, telefono, correo, contacto_emergencia, telefono_emergencia, fecha_nacimiento, foto_perfil) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, dp.getDni());
            ps.setString(2, dp.getNombres());
            ps.setString(3, dp.getPrimerApellido());
            ps.setString(4, dp.getSegundoApellido());
            ps.setString(5, dp.getTelefono());
            ps.setString(6, dp.getCorreo());
            ps.setString(7, dp.getContactoEmergencia());
            ps.setString(8, dp.getTelefonoEmergencia());
            ps.setString(9, dp.getFechaNacimiento());
            ps.setString(10, dp.getFotoPerfil());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.out.println("❌ Error al insertar datos personales: " + e.getMessage());
            return false;
        }
    }
}
