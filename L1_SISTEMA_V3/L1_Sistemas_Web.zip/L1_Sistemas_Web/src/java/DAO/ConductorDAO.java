package DAO;

import MODELO.Conductor;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ConductorDAO {
    // Filtro por DNI, modalidad y estado (sin fecha de ingreso)
    public List<Conductor> filtrarConductores(String dni, String modalidad, String estado) {
        List<Conductor> lista = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT * FROM Conductores WHERE 1=1");
        List<Object> parametros = new ArrayList<>();

        if (dni != null && !dni.isEmpty()) {
            sql.append(" AND dni LIKE ?");
            parametros.add("%" + dni + "%");
        }
        if (modalidad != null && !modalidad.isEmpty()) {
            sql.append(" AND tipo_conductor = ?");
            parametros.add(modalidad);
        }
        if (estado != null && !estado.isEmpty()) {
            sql.append(" AND estado = ?");
            parametros.add(estado);
        }

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {
            for (int i = 0; i < parametros.size(); i++) {
                ps.setObject(i + 1, parametros.get(i));
            }
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Conductor c = new Conductor();
                c.setIdConductor(rs.getInt("id_conductor"));
                c.setDni(rs.getString("dni"));
                c.setNombreCompleto(rs.getString("nombre_completo"));
                c.setTipoConductor(rs.getString("tipo_conductor"));
                c.setBaseAsignada(rs.getString("base_asignada"));
                c.setHabilitadoEnsenar(rs.getBoolean("habilitado_ensenar"));
                c.setEstado(rs.getString("estado"));
                c.setSaldoTiempo(rs.getString("saldo_tiempo"));
                // Si tienes más campos, agrégalos aquí
                lista.add(c);
            }
        } catch (Exception e) {
            System.out.println("❌ Error listando conductores: " + e.getMessage());
        }
        return lista;
    }

    // Listar todo sin filtros
    public List<Conductor> listar() {
        return filtrarConductores(null, null, null);
    }

    public boolean agregar(Conductor c) {
        String sql = "INSERT INTO Conductores (dni, nombre_completo, tipo_conductor, base_asignada, habilitado_ensenar, estado, saldo_tiempo) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getDni());
            ps.setString(2, c.getNombreCompleto());
            ps.setString(3, c.getTipoConductor());
            ps.setString(4, c.getBaseAsignada());
            ps.setBoolean(5, c.isHabilitadoEnsenar());
            ps.setString(6, c.getEstado());
            ps.setString(7, c.getSaldoTiempo());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.out.println("❌ Error agregando conductor: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(Conductor c) {
        String sql = "UPDATE Conductores SET nombre_completo=?, tipo_conductor=?, base_asignada=?, habilitado_ensenar=?, estado=?, saldo_tiempo=? WHERE dni=?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getNombreCompleto());
            ps.setString(2, c.getTipoConductor());
            ps.setString(3, c.getBaseAsignada());
            ps.setBoolean(4, c.isHabilitadoEnsenar());
            ps.setString(5, c.getEstado());
            ps.setString(6, c.getSaldoTiempo());
            ps.setString(7, c.getDni());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.out.println("❌ Error actualizando conductor: " + e.getMessage());
            return false;
        }
    }

    public boolean cambiarEstado(int idConductor, String estado) {
        String sql = "UPDATE Conductores SET estado=? WHERE id_conductor=?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, estado);
            ps.setInt(2, idConductor);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.out.println("❌ Error cambiando estado conductor: " + e.getMessage());
            return false;
        }
    }
}
