package DAO;

import java.sql.*;

public class UsuarioDAO {

    // Cambiar contraseña de usuario por DNI (usuario)
    public boolean cambiarContrasena(String dni, String actual, String nueva) {
        String sqlCheck = "SELECT * FROM Usuarios WHERE usuario = ? AND contrasena_hash = ?";
        String sqlUpdate = "UPDATE Usuarios SET contrasena_hash = ? WHERE usuario = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement psCheck = con.prepareStatement(sqlCheck)) {
            psCheck.setString(1, dni);
            psCheck.setString(2, actual); // Aplica hash si usas hash
            ResultSet rs = psCheck.executeQuery();
            if (rs.next()) {
                try (PreparedStatement psUpdate = con.prepareStatement(sqlUpdate)) {
                    psUpdate.setString(1, nueva); // Aplica hash si usas hash
                    psUpdate.setString(2, dni);
                    int rows = psUpdate.executeUpdate();
                    return rows > 0;
                }
            }
        } catch (Exception e) {
            System.out.println("❌ Error cambiando contraseña: " + e.getMessage());
        }
        return false;
    }

    // Obtener nombre del usuario por DNI
    public String obtenerNombrePorDni(String dni) {
        String sql = "SELECT nombres FROM DatosPersonales WHERE dni = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, dni);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString("nombres");
            }
        } catch (Exception e) {
            System.out.println("❌ Error obteniendo nombre: " + e.getMessage());
        }
        return dni; // Por defecto el DNI
    }
}
