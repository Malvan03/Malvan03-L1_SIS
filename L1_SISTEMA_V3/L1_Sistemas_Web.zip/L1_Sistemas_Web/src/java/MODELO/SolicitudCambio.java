package MODELO;

public class SolicitudCambio {
    private int id;
    private String fechaSolicitud;
    private int idConductorSolicitante;
    private int idConductorReceptor;
    private int idAsignacionOriginal;
    private int idAsignacionSolicitada;
    private String nombreSolicitante;
    private String nombreReceptor;
    private String turnoSolicitante;
    private String turnoReceptor;
    private String observacionAdmin;
    private String comentariosConductor;

    // Getters y setters...
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getFechaSolicitud() { return fechaSolicitud; }
    public void setFechaSolicitud(String fechaSolicitud) { this.fechaSolicitud = fechaSolicitud; }

    public int getIdConductorSolicitante() { return idConductorSolicitante; }
    public void setIdConductorSolicitante(int idConductorSolicitante) { this.idConductorSolicitante = idConductorSolicitante; }

    public int getIdConductorReceptor() { return idConductorReceptor; }
    public void setIdConductorReceptor(int idConductorReceptor) { this.idConductorReceptor = idConductorReceptor; }

    public int getIdAsignacionOriginal() { return idAsignacionOriginal; }
    public void setIdAsignacionOriginal(int idAsignacionOriginal) { this.idAsignacionOriginal = idAsignacionOriginal; }

    public int getIdAsignacionSolicitada() { return idAsignacionSolicitada; }
    public void setIdAsignacionSolicitada(int idAsignacionSolicitada) { this.idAsignacionSolicitada = idAsignacionSolicitada; }

    public String getNombreSolicitante() { return nombreSolicitante; }
    public void setNombreSolicitante(String nombreSolicitante) { this.nombreSolicitante = nombreSolicitante; }

    public String getNombreReceptor() { return nombreReceptor; }
    public void setNombreReceptor(String nombreReceptor) { this.nombreReceptor = nombreReceptor; }

    public String getTurnoSolicitante() { return turnoSolicitante; }
    public void setTurnoSolicitante(String turnoSolicitante) { this.turnoSolicitante = turnoSolicitante; }

    public String getTurnoReceptor() { return turnoReceptor; }
    public void setTurnoReceptor(String turnoReceptor) { this.turnoReceptor = turnoReceptor; }

    public String getObservacionAdmin() { return observacionAdmin; }
    public void setObservacionAdmin(String observacionAdmin) { this.observacionAdmin = observacionAdmin; }

    public String getComentariosConductor() { return comentariosConductor; }
    public void setComentariosConductor(String comentariosConductor) { this.comentariosConductor = comentariosConductor; }
}
