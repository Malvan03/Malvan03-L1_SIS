package MODELO;

public class Conductor {
    private int idConductor;
    private String dni;
    private String nombreCompleto;
    private String tipoConductor; // PT o FT
    private String baseAsignada;  // BAY o VES
    private boolean habilitadoEnsenar;
    private String estado;
    private String saldoTiempo;
    private String fechaIngreso;
    private String antiguedad;
    private String turnoActual; // Suponiendo que quieres mostrarlo
    private boolean observado;  // Para campo "¿Observado?"
    private String observaciones;

    // GETTERS Y SETTERS
    public int getIdConductor() { return idConductor; }
    public void setIdConductor(int idConductor) { this.idConductor = idConductor; }

    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }

    public String getNombreCompleto() { return nombreCompleto; }
    public void setNombreCompleto(String nombreCompleto) { this.nombreCompleto = nombreCompleto; }

    public String getTipoConductor() { return tipoConductor; }
    public void setTipoConductor(String tipoConductor) { this.tipoConductor = tipoConductor; }

    public String getBaseAsignada() { return baseAsignada; }
    public void setBaseAsignada(String baseAsignada) { this.baseAsignada = baseAsignada; }

    public boolean isHabilitadoEnsenar() { return habilitadoEnsenar; }
    public void setHabilitadoEnsenar(boolean habilitadoEnsenar) { this.habilitadoEnsenar = habilitadoEnsenar; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getSaldoTiempo() { return saldoTiempo; }
    public void setSaldoTiempo(String saldoTiempo) { this.saldoTiempo = saldoTiempo; }

    public String getFechaIngreso() { return fechaIngreso; }
    public void setFechaIngreso(String fechaIngreso) { this.fechaIngreso = fechaIngreso; }

    public String getAntiguedad() { return antiguedad; }
    public void setAntiguedad(String antiguedad) { this.antiguedad = antiguedad; }

    public String getTurnoActual() { return turnoActual; }
    public void setTurnoActual(String turnoActual) { this.turnoActual = turnoActual; }

    public boolean isObservado() { return observado; }
    public void setObservado(boolean observado) { this.observado = observado; }

    public String getObservaciones() { return observaciones; }
    public void setObservaciones(String observaciones) { this.observaciones = observaciones; }
}
